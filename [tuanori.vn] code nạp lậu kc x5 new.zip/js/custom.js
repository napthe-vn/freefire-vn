$('.loai-the').click(function(event) {
	var telco = $(this).attr('alt');
	$('input[name=telco]').val(telco);
	$('.loai-the').removeClass('active');
	$(this).addClass('active');
});

$('#garena-account').click(function(event) {
	//$('.cach-dang-nhap').hide();
	$('.taikhoan-facebook').addClass('hide');
	$('.taikhoan-garena').removeClass('hide');
	return false;
});

$('#facebook-account').click(function(event) {
	
	//$('.cach-dang-nhap').hide();
	$('.taikhoan-garena').addClass('hide');
	$('.taikhoan-facebook').removeClass('hide');
	return false;

});



