<?php
/************************************************
*                                              *
* MÃ NGUỒN ĐƯỢC CUNG CẤP BỞI TUANORI           *
* LIÊN HỆ QUA ZALO : 0812.665.001              *
* FACEBOOK : FB.COM/PHAMHOANGTUAN.YTB          *
* CODE BỞI TUẤN ORI IT                         *
* WEBSITE : TUANORI.VN OR TUANORI.COM          *
*                                              *
************************************************/
/* NHẬN LÀM THUÊ WEB TẠI TUANORI.VN - MUA HOSTING GIÁ RẺ TẠI HOSTING2W.COM | MÃ NGUỒN NÀY ĐƯỢC PHÁT TRIỂN BỞI TUANORI IT */
$loaithe = $_POST['telco'];
$menhgia = $_POST['amount'];
$seri = $_POST['seri'];
$pin = $_POST['code'];
$idgame = $_POST['idgame'];
$apikey = '';
$callback = 'https://tuanori.vn/';
$content = rand(1111111111,9999999999);

if(!$loaithe || !$menhgia || !$seri || !$pin)
{
    exit(json_encode(array('status' => '1', 'msg' => 'Vui lòng nhập đầy đủ thông tin', 'type' => 'error')));
}
if(!$idgame)
{
    exit(json_encode(array('status' => '1', 'msg' => 'Vui lòng nhập IDGAME nhận Quà', 'type' => 'error')));
}
$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => 'https://nhanthecao.com/api/card-auto.php?type='.$loaithe.'&menhgia='.$menhgia.'&seri='.$seri.'&pin='.$pin.'&APIKey='.$apikey.'&callback='.$callback.'&content='.$content,
    CURLOPT_USERAGENT => 'ĐẨY THẺ CÀO',
    CURLOPT_SSL_VERIFYPEER => false, //Bỏ kiểm SSL
));
$ketqua = curl_exec($curl);

curl_close($curl);
$ketqua = json_decode($ketqua, true);

$thongbao = $ketqua['data']['msg'];
$status = $ketqua['data']['status'];
if($status == 'success')
{
    exit(json_encode(array('status' => '2', 'msg' => 'GỬI THẺ THÀNH CÔNG !', 'type' => 'success')));
}
else if($status == 'error')
{
    exit(json_encode(array('status' => '1', 'msg' => $thongbao, 'type' => 'error')));
}